
//
//  ViewController.swift
//  Thirunagari_GroceryApp
//
//  Created by Thirunagari,Vamshi Krishna on 4/04/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var grocerySectionsTableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Grocery Sections"
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
    }
    
    @objc func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return grocerysArr.count;
        }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            var cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
            cell.textLabel?.text = grocerysArr[indexPath.row].section
            return cell
        }
        
        var grocery = Grocery()
        
        var grocerysArr = grocerys

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "itemsSegue"{
                let destination = segue.destination as! GroceryItemsViewController
                destination.items = grocerysArr[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
            }
        }
    
    
}

