//
//  ItemInfoViewController.swift
//  Thirunagari_GroceryApp
//
//  Created by Thirunagari,Vamshi Krishna on 4/04/22.
//


import UIKit

class ItemInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad()
        self.title = details?.itemName
        ItemInfoOutlet.isHidden = true
        var imgn = details?.itemImage
        itemImageViewOutlet.image = UIImage(named: imgn!)
        let originalImageFrame = itemImageViewOutlet.frame
        let widthShrink: CGFloat = 30
        let heightShrink: CGFloat = 30
        let newFrame = CGRect(
        x: itemImageViewOutlet.frame.origin.x + widthShrink,
        y: itemImageViewOutlet.frame.origin.y + heightShrink,
        width: itemImageViewOutlet.frame.width - widthShrink,
        height: itemImageViewOutlet.frame.height - heightShrink)
        itemImageViewOutlet.frame = newFrame
        UIView.animate(withDuration: 1.0, delay: 0.7, usingSpringWithDamping: 0.3, initialSpringVelocity: 30.0,  animations: {
            self.itemImageViewOutlet.frame = originalImageFrame
                            })
    }
    
    @IBAction func showItemInfoAction(_ sender: Any) {
        ItemInfoOutlet.isHidden = false
        ItemInfoOutlet.text = details?.itemInfo
    }
    
    @IBOutlet weak var ItemInfoOutlet: UITextView!
    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    var details : GroceryItem?
    
    
}

